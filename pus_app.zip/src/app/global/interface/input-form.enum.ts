export enum InputTypeEnum {
  Text = 'Text',
  Textarea = 'Textarea',
  Number = 'Number',
  Password = 'Password',
  Mask = 'Mask',
  Date = 'Date',
  Color = 'Color',
  Select = 'Select',
  MultiSelect = 'MultiSelect',
  Radio = 'Radio',
  Checkbox = 'Checkbox',
  AutoComplete = 'AutoComplete',
  CascadeSelect = 'CascadeSelect',
  TreeSelect = 'TreeSelect',
  Listbox = 'Listbox',
  ToggleSwitch = 'ToggleSwitch',
  TriStateCheckbox = 'TriStateCheckbox',
  Slider = 'Slider',
  RangeSlider = 'RangeSlider',
  Rating = 'Rating'
}

export enum InputSimpleTypeEnum {
  Text = 'Text',
  Textarea = 'Textarea',
  Number = 'Number',
  Password = 'Password',
  Mask = 'Mask',
  Date = 'Date',
  Color = 'Color'
}

export enum InputSelectionTypeEnum {
  Select = 'Select',
  MultiSelect = 'MultiSelect',
  Radio = 'Radio',
  Checkbox = 'Checkbox',
  AutoComplete = 'AutoComplete',
  CascadeSelect = 'CascadeSelect',
  TreeSelect = 'TreeSelect',
  Listbox = 'Listbox'
}

export enum InputConditionTypeEnum {
  ToggleSwitch = 'ToggleSwitch',
  TriStateCheckbox = 'TriStateCheckbox',
  Slider = 'Slider',
  RangeSlider = 'RangeSlider',
  Rating = 'Rating'
}

export enum InputGroupEnum {
  Simple = 'Simple',
  Selection = 'Selection',
  Condition = 'Condition'
}