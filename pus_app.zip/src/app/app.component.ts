import { Component, inject, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { datasGlobalI } from './global/interface/data.interface';
import {
  FormChangeInterface, FormSubmitInterface, InputChangeInterface
} from './global/interface/input-form.interface';
import { ServerService } from './global/service/server.service';
import { ServerRequestActionEnum } from './global/interface/server.enum';
import { dataTypeE, UIActionEnum, UIComponentEnum, UISeverityEnum, UISortDirectionEnum, UIVariantEnum, UIViewModeEnum } from './global/interface/data.enums';
 
import { InputGroupEnum, InputTypeEnum } from './global/interface/input-form.enum';
import { ButtonEventI } from './modules/button/button.component';

@Component({
  selector: 'pus-root',
  standalone: false,
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent implements OnInit {
  private readonly http = inject(HttpClient);
  public forms_datas: datasGlobalI = undefined as any;

  readonly inputsSchema$ = this.http.get<datasGlobalI[]>(
    'assets/forms/all-inputs.json'
  );
  readonly formSchema$ = this.http.get<datasGlobalI>(
    'assets/forms/forms.json'
  );

  readonly testButtons:datasGlobalI[]=[
    {
      _id:'btn_create',
      name:'Créer',
      description:'Créer un nouvel élément',
      dataType:dataTypeE.String,
      dataKey:'create',
      uiComponent:UIComponentEnum.Button,
      configurations:{
        icon:'pi pi-plus',
        severity:UISeverityEnum.Success,
        variant:UIVariantEnum.Filled
      }
    },
    {
      _id:'btn_edit',
      name:'Modifier',
      description:'Modifier l’élément sélectionné',
      dataType:dataTypeE.String,
      dataKey:'edit',
      uiComponent:UIComponentEnum.Button,
      configurations:{
        icon:'pi pi-pencil',
        severity:UISeverityEnum.Primary,
        variant:UIVariantEnum.Outlined
      }
    },
    {
      _id:'btn_delete',
      name:'Supprimer',
      description:'Supprimer l’élément sélectionné',
      dataType:dataTypeE.String,
      dataKey:'delete',
      uiComponent:UIComponentEnum.Button,
      configurations:{
        icon:'pi pi-trash',
        severity:UISeverityEnum.Danger,
        variant:UIVariantEnum.Filled
      }
    },
    {
      _id:'btn_disabled',
      name:'Archiver',
      description:'Bouton désactivé pour test',
      dataType:dataTypeE.String,
      dataKey:'archive',
      uiComponent:UIComponentEnum.Button,
      controls:{
        disabled:true
      },
      configurations:{
        icon:'pi pi-box',
        severity:UISeverityEnum.Secondary
      }
    }, 
    {
      _id:'btn_more',
      name:'Plus',
      description:'Bouton avec actions enfants',
      dataType:dataTypeE.String,
      dataKey:'more',
      uiComponent:UIComponentEnum.Button,
      configurations:{
        icon:'pi pi-ellipsis-v',
        severity:UISeverityEnum.Secondary
      },
      buttons:[
        {
          _id:'btn_view',
          name:'Voir',
          description:'Afficher les détails',
          dataType:dataTypeE.String,
          dataKey:'view',
          uiComponent:UIComponentEnum.Button,
          configurations:{
            icon:'pi pi-eye'
          }
        },
        {
          _id:'btn_duplicate',
          name:'Dupliquer',
          description:'Dupliquer l’élément',
          dataType:dataTypeE.String,
          dataKey:'duplicate',
          uiComponent:UIComponentEnum.Button,
          configurations:{
            icon:'pi pi-copy'
          }
        },
        {
          _id:'btn_export',
          name:'Exporter',
          description:'Exporter les données',
          dataType:dataTypeE.String,
          dataKey:'export',
          uiComponent:UIComponentEnum.Button,
          configurations:{
            icon:'pi pi-download'
          }
        }
      ]
    }
  ];

  
  readonly toolbarData:datasGlobalI={
  _id:'toolbar_users',
  name:'Utilisateurs',
  label:'Utilisateurs',
  description:'Gestion des utilisateurs du système',
  dataType:dataTypeE.Mixed,
  dataKey:'usersToolbar',
  uiComponent:UIComponentEnum.Toolbar,

  controls:{
    disabled:false,
    loading:false,
    showBack:true
  },

  configurations:{
    icon:'pi pi-users',
    count:245,
    selectedCount:0
  },

  inputs:[
    {
      _id:'toolbar_search',
      name:'Recherche',
      description:'Rechercher dans la liste',
      dataType:dataTypeE.String,
      dataKey:'search',
      uiComponent:UIComponentEnum.Input,
      inputGroup:InputGroupEnum.Simple,
      inputType:InputTypeEnum.Text,
      value:'',
      controls:{
        disabled:false,
        hidden:false,
        showClear:true
      },
      configurations:{
        action:UIActionEnum.Search,
        placeholder:'Rechercher...',
        icon:'pi pi-search',
        debounce:300
      }
    },

    {
      _id:'toolbar_filter_status',
      name:'Statut',
      description:'Filtrer selon le statut',
      dataType:dataTypeE.String,
      dataKey:'status',
      uiComponent:UIComponentEnum.Input,
      inputGroup:InputGroupEnum.Selection,
      inputType:InputTypeEnum.Select,
      value:null,
      controls:{
        disabled:false,
        hidden:false,
        showClear:true,
        filter:true
      },
      configurations:{
        action:UIActionEnum.Filter,
        placeholder:'Tous les statuts'
      },
      resources:[
        {name:'Actif',value:'active'},
        {name:'Inactif',value:'inactive'},
        {name:'Bloqué',value:'blocked'}
      ]
    },

    {
      _id:'toolbar_filter_type',
      name:'Type',
      description:'Filtrer selon le type',
      dataType:dataTypeE.String,
      dataKey:'type',
      uiComponent:UIComponentEnum.Input,
      inputGroup:InputGroupEnum.Selection,
      inputType:InputTypeEnum.Select,
      value:null,
      controls:{
        disabled:false,
        hidden:false,
        showClear:true,
        filter:true
      },
      configurations:{
        action:UIActionEnum.Filter,
        placeholder:'Tous les types'
      },
      resources:[
        {name:'Administrateur',value:'admin'},
        {name:'Utilisateur',value:'user'},
        {name:'Invité',value:'guest'}
      ]
    },

    {
      _id:'toolbar_sort_name',
      name:'Nom',
      description:'Trier par nom',
      dataType:dataTypeE.String,
      dataKey:'name',
      uiComponent:UIComponentEnum.Input,
      value:'name',
      controls:{
        disabled:false,
        hidden:false,
        selected:true
      },
      configurations:{
        action:UIActionEnum.Sort,
        sortDirection:UISortDirectionEnum.Asc
      }
    },

    {
      _id:'toolbar_sort_createdAt',
      name:'Date de création',
      description:'Trier par date de création',
      dataType:dataTypeE.String,
      dataKey:'createdAt',
      uiComponent:UIComponentEnum.Input,
      value:'createdAt',
      controls:{
        disabled:false,
        hidden:false,
        selected:false
      },
      configurations:{
        action:UIActionEnum.Sort
      }
    },

    {
      _id:'toolbar_sort_updatedAt',
      name:'Dernière modification',
      description:'Trier par dernière modification',
      dataType:dataTypeE.String,
      dataKey:'updatedAt',
      uiComponent:UIComponentEnum.Input,
      value:'updatedAt',
      controls:{
        disabled:false,
        hidden:false,
        selected:false
      },
      configurations:{
        action:UIActionEnum.Sort
      }
    },

    {
      _id:'toolbar_view_table',
      name:'Table',
      description:'Afficher en tableau',
      dataType:dataTypeE.String,
      dataKey:'table',
      uiComponent:UIComponentEnum.Input,
      value:'table',
      controls:{
        disabled:false,
        hidden:false,
        selected:true
      },
      configurations:{
        action:UIActionEnum.View,
        viewMode:UIViewModeEnum.Table,
        icon:'pi pi-table'
      }
    },

    {
      _id:'toolbar_view_list',
      name:'Liste',
      description:'Afficher en liste',
      dataType:dataTypeE.String,
      dataKey:'list',
      uiComponent:UIComponentEnum.Input,
      value:'list',
      controls:{
        disabled:false,
        hidden:false,
        selected:false
      },
      configurations:{
        action:UIActionEnum.View,
        viewMode:UIViewModeEnum.List,
        icon:'pi pi-list'
      }
    },

    {
      _id:'toolbar_view_grid',
      name:'Grille',
      description:'Afficher en grille',
      dataType:dataTypeE.String,
      dataKey:'grid',
      uiComponent:UIComponentEnum.Input,
      value:'grid',
      controls:{
        disabled:false,
        hidden:false,
        selected:false
      },
      configurations:{
        action:UIActionEnum.View,
        viewMode:UIViewModeEnum.Grid,
        icon:'pi pi-th-large'
      }
    }
  ],

  buttons:[
    {
      _id:'btn_create',
      name:'Créer',
      description:'Créer un nouvel utilisateur',
      dataType:dataTypeE.String,
      dataKey:'create',
      uiComponent:UIComponentEnum.Button,
      controls:{
        disabled:false,
        hidden:false,
        selectionOnly:false
      },
      configurations:{
        action:UIActionEnum.Create,
        icon:'pi pi-plus',
        severity:UISeverityEnum.Success,
        variant:UIVariantEnum.Filled
      }
    },

    {
      _id:'btn_refresh',
      name:'Actualiser',
      description:'Actualiser les données',
      dataType:dataTypeE.String,
      dataKey:'refresh',
      uiComponent:UIComponentEnum.Button,
      controls:{
        disabled:false,
        hidden:false,
        selectionOnly:false
      },
      configurations:{
        action:UIActionEnum.Refresh,
        icon:'pi pi-refresh',
        severity:UISeverityEnum.Secondary,
        variant:UIVariantEnum.Outlined
      }
    },

    {
      _id:'btn_delete_selected',
      name:'Supprimer',
      description:'Supprimer les éléments sélectionnés',
      dataType:dataTypeE.String,
      dataKey:'deleteSelected',
      uiComponent:UIComponentEnum.Button,
      controls:{
        disabled:false,
        hidden:false,
        selectionOnly:true
      },
      configurations:{
        action:UIActionEnum.Delete,
        icon:'pi pi-trash',
        severity:UISeverityEnum.Danger,
        variant:UIVariantEnum.Filled
      }
    },

    {
      _id:'btn_export_selected',
      name:'Exporter',
      description:'Exporter les éléments sélectionnés',
      dataType:dataTypeE.String,
      dataKey:'exportSelected',
      uiComponent:UIComponentEnum.Button,
      controls:{
        disabled:false,
        hidden:false,
        selectionOnly:true
      },
      configurations:{
        action:UIActionEnum.Export,
        icon:'pi pi-download',
        severity:UISeverityEnum.Secondary,
        variant:UIVariantEnum.Outlined
      }
    },

    {
      _id:'btn_more',
      name:'Plus',
      description:'Actions supplémentaires',
      dataType:dataTypeE.String,
      dataKey:'more',
      uiComponent:UIComponentEnum.Button,
      controls:{
        disabled:false,
        hidden:false,
        selectionOnly:false
      },
      configurations:{
        icon:'pi pi-ellipsis-v',
        severity:UISeverityEnum.Secondary
      },
      buttons:[
        {
          _id:'btn_import',
          name:'Importer',
          description:'Importer des données',
          dataType:dataTypeE.String,
          dataKey:'import',
          uiComponent:UIComponentEnum.Button,
          configurations:{
            action:UIActionEnum.Import,
            icon:'pi pi-upload'
          }
        },
        {
          _id:'btn_print',
          name:'Imprimer',
          description:'Imprimer la liste',
          dataType:dataTypeE.String,
          dataKey:'print',
          uiComponent:UIComponentEnum.Button,
          configurations:{
            action:UIActionEnum.Print,
            icon:'pi pi-print'
          }
        }
      ]
    }
  ]
};


readonly dataView: datasGlobalI = {
  _id:'dataview_users',
  name:'Utilisateurs',
  label:'Utilisateurs',
  description:'Liste des utilisateurs du système',
  dataType:dataTypeE.Array,
  dataKey:'users',
  uiComponent:UIComponentEnum.DataView,

  controls:{
    disabled:false,
    loading:false,
    selectable:true,
    multiple:false,
    paginator:true,
    lazy:false,
    stripedRows:true,
    showGridlines:false,
    resizable:true,
    reorderable:false
  },

  configurations:{
    viewMode:UIViewModeEnum.Grid,
    trackBy:'_id',
    pageSize:10,
    pageIndex:0,
    totalRecords:5,
    rowsPerPageOptions:[10,25,50,100]
  },

  columns:[
    {
      _id:'col_name',
      name:'Nom',
      label:'Nom',
      description:'Nom complet',
      dataType:dataTypeE.String,
      dataKey:'name',
      controls:{
        hidden:false,
        sortable:true
      },
      configurations:{
        icon:'pi pi-user'
      }
    },
    {
      _id:'col_email',
      name:'Email',
      label:'Email',
      description:'Adresse email',
      dataType:dataTypeE.String,
      dataKey:'email',
      controls:{
        hidden:false,
        sortable:true
      },
      configurations:{
        icon:'pi pi-envelope'
      }
    },
    {
      _id:'col_age',
      name:'Âge',
      label:'Âge',
      description:'Âge utilisateur',
      dataType:dataTypeE.Number,
      dataKey:'age',
      controls:{
        hidden:false,
        sortable:true
      },
      configurations:{
        suffix:' ans'
      }
    },
    {
      _id:'col_status',
      name:'Statut',
      label:'Statut',
      description:'Statut utilisateur',
      dataType:dataTypeE.String,
      dataKey:'status',
      controls:{
        hidden:false,
        sortable:true
      }
    },
    {
      _id:'col_city',
      name:'Ville',
      label:'Ville',
      description:'Ville de résidence',
      dataType:dataTypeE.String,
      dataKey:'address.city',
      controls:{
        hidden:false,
        sortable:false
      },
      configurations:{
        icon:'pi pi-map-marker'
      }
    }
  ],

  resources:[
    {
      _id:'u001',
      name:'Jean Kabungulu',
      email:'jean@peka.com',
      age:27,
      status:'Actif',
      address:{
        city:'Bukavu',
        country:'RDC'
      }
    },
    {
      _id:'u002',
      name:'Paul Mbuyi',
      email:'paul@peka.com',
      age:31,
      status:'Inactif',
      address:{
        city:'Goma',
        country:'RDC'
      }
    },
    {
      _id:'u003',
      name:'Grace Mwamba',
      email:'grace@peka.com',
      age:29,
      status:'Actif',
      address:{
        city:'Butembo',
        country:'RDC'
      }
    },
    {
      _id:'u004',
      name:'Daniel Kasongo',
      email:'daniel@peka.com',
      age:35,
      status:'Bloqué',
      address:{
        city:'Kinshasa',
        country:'RDC'
      }
    },
    {
      _id:'u005',
      name:'Sarah Bahati',
      email:'sarah@peka.com',
      age:26,
      status:'Actif',
      address:{
        city:'Bukavu',
        country:'RDC'
      }
    }
  ],
 
};






  constructor(private ServerS: ServerService) { }
  ngOnInit(): void {

    this.ServerS.send<never, datasGlobalI>(
      'databases',
      'keys',
      ServerRequestActionEnum.FindAll,
      undefined, undefined
    ).subscribe(response => {
      console.log(response.datas);
      console.log(response.meta?.total);
    });


    this.formSchema$.subscribe(data => this.forms_datas = data);
  }





  onRowClick(event:any):void {
  console.log('ROW:',event.resource);
}

onRowDoubleClick(event:any):void {
  console.log('DOUBLE CLICK:',event.resource);
}

onSelectionChange(resources:Record<string,unknown>[]):void {
  console.log('SELECTION:',resources);
}

onPageChange(event:any):void {
  console.log('PAGE:',event);
}

onSortChange(event:any):void {
  console.log('SORT:',event);
}

onDataViewButton(event:any):void {
  console.log('ACTION:',event.button.dataKey,'RESOURCE:',event.resource);
}



















onBack( ):void { 
}



 onToolbarBack():void {
  console.log('BACK');
}

onToolbarSearch(event:any):void {
  console.log('SEARCH CHANGE:',event.data.dataKey,event.value);
}

onToolbarSearchSubmit(event:any):void {
  console.log('SEARCH SUBMIT:',event.value);
}

onToolbarFilter(event:any):void {
  console.log('FILTER:',event.data.dataKey,event.value);
}

onToolbarFilters(values:Record<string,unknown>):void {
  console.log('ALL FILTERS:',values);
}

onToolbarSort(event:any):void {
  console.log('SORT:',event.data.dataKey,event.direction);
}

onToolbarView(event:any):void {
  console.log('VIEW:',event.data.dataKey,event.value);
}

onToolbarButton(event:ButtonEventI):void {
  console.log('BUTTON:',event.button.dataKey);
}










  onButtonClick(event:any):void {
  console.log('CLICK:',event.button.dataKey,event.button);
}

  onFormChange(event: FormChangeInterface): void {
    console.log('FORM CHANGE', event);
  }

  onFieldChange(event: InputChangeInterface): void {
    console.log('INPUT CHANGE', event.key, event.value);
  }

  onFieldBlur(event: InputChangeInterface): void {
    console.log('INPUT BLUR', event.key, event.value);
  }

  onSubmit(event: FormSubmitInterface): void {
    console.log('SUBMIT', event.rawValue);
  }
}