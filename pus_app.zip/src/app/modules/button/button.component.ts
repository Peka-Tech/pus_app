import { ChangeDetectionStrategy, Component, EventEmitter, HostListener, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { datasGlobalI } from '../../global/interface/data.interface';
import { UIVariantEnum } from '../../global/interface/data.enums';

export interface ButtonEventI {
  button:datasGlobalI;
  event?:Event;
}

@Component({
  selector:'pus-button',
  standalone:false,
  templateUrl:'./button.component.html',
  styleUrl:'./button.component.scss',
  changeDetection:ChangeDetectionStrategy.OnPush
})
export class ButtonComponent implements OnInit,OnChanges {

  @Input() buttons:datasGlobalI[]=[];
  @Input() breakpoint=900;
  @Input() desktopLimit=5;
  @Input() mobileLimit=2;
  @Input() groupLabel='Options';
  @Input() groupIcon='pi pi-ellipsis-v';

  @Output() buttonClick=new EventEmitter<ButtonEventI>();

  isSmallScreen=false;

  groupedItems:MenuItem[]=[];
  childMenus:Record<string,MenuItem[]>={};

  ngOnInit():void {
    this.updateScreenMode();
    this.refresh();
  }

  ngOnChanges(changes:SimpleChanges):void {
    if(changes['buttons']||changes['breakpoint']||changes['desktopLimit']||changes['mobileLimit']){
      this.updateScreenMode();
      this.refresh();
    }
  }

  @HostListener('window:resize')
  onResize():void {
    const previous=this.isSmallScreen;

    this.updateScreenMode();

    if(previous!==this.isSmallScreen){
      this.refresh();
    }
  }

  get visibleButtons():datasGlobalI[] {
    return this.buttons.filter(button=>!this.isHidden(button));
  }

  get useGroupMode():boolean {
    const limit=this.isSmallScreen?this.mobileLimit:this.desktopLimit;
    return this.visibleButtons.length>limit;
  }

  hasChildren(button:datasGlobalI):boolean {
    return (button.buttons??[]).some(child=>!this.isHidden(child));
  }

  getLabel(button:datasGlobalI):string {
    return button.label??button.name;
  }

  getIcon(button:datasGlobalI):string|undefined {
    return button.configurations?.icon;
  }

  getSeverity(button:datasGlobalI):any {
    return button.configurations?.severity?.toString().toLowerCase();
  }

  isDisabled(button:datasGlobalI):boolean {
    return button.controls?.disabled===true;
  }

  isHidden(button:datasGlobalI):boolean {
    return button.controls?.hidden===true;
  }

  isOutlined(button:datasGlobalI):boolean {
    return button.configurations?.variant===UIVariantEnum.Outlined;
  }

  isText(button:datasGlobalI):boolean {
    const variant=button.configurations?.variant;

    return variant===UIVariantEnum.Text||
           variant===UIVariantEnum.Ghost||
           variant===UIVariantEnum.Link;
  }

  onClick(button:datasGlobalI,event?:Event):void {
    if(this.isDisabled(button)) return;

    this.buttonClick.emit({
      button,
      event
    });
  }

  private updateScreenMode():void {
    this.isSmallScreen=window.innerWidth<this.breakpoint;
  }

  private refresh():void {
    const buttons=this.visibleButtons;

    this.childMenus={};

    for(const button of buttons){
      if(this.hasChildren(button)){
        this.childMenus[button._id]=this.buildMenuItems(button.buttons??[]);
      }
    }

    this.groupedItems=this.buildMenuItems(buttons);
  }

  private buildMenuItems(buttons:datasGlobalI[]):MenuItem[] {
    return buttons
      .filter(button=>!this.isHidden(button))
      .map(button=>this.buildMenuItem(button));
  }

  private buildMenuItem(button:datasGlobalI):MenuItem {
    const children=(button.buttons??[])
      .filter(child=>!this.isHidden(child));

    if(children.length>0){
      return {
        id:button._id,
        label:this.getLabel(button),
        icon:this.getIcon(button),
        disabled:this.isDisabled(button),
        items:children.map(child=>this.buildMenuItem(child))
      };
    }

    return {
      id:button._id,
      label:this.getLabel(button),
      icon:this.getIcon(button),
      disabled:this.isDisabled(button),
      command:(event)=>{
        this.onClick(button,event.originalEvent);
      }
    };
  }
}