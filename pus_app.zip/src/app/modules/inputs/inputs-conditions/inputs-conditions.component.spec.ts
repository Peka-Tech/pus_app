import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InputsConditionsComponent } from './inputs-conditions.component';

describe('InputsConditionsComponent', () => {
  let component: InputsConditionsComponent;
  let fixture: ComponentFixture<InputsConditionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [InputsConditionsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InputsConditionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
