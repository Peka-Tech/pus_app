import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InputsSimplesComponent } from './inputs-simples.component';

describe('InputsSimplesComponent', () => {
  let component: InputsSimplesComponent;
  let fixture: ComponentFixture<InputsSimplesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [InputsSimplesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InputsSimplesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
