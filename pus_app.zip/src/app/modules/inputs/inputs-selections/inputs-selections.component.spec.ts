import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InputsSelectionsComponent } from './inputs-selections.component';

describe('InputsSelectionsComponent', () => {
  let component: InputsSelectionsComponent;
  let fixture: ComponentFixture<InputsSelectionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [InputsSelectionsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InputsSelectionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
