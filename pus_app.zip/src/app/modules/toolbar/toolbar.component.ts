import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnChanges, OnDestroy, Output, SimpleChanges } from '@angular/core';
import { datasGlobalI } from '../../global/interface/data.interface';
import { UIActionEnum, UISortDirectionEnum, UIViewModeEnum } from '../../global/interface/data.enums';
import { ButtonEventI } from '../button/button.component';

@Component({
  selector:'pus-toolbar',
  standalone:false,
  templateUrl:'./toolbar.component.html',
  styleUrl:'./toolbar.component.scss',
  changeDetection:ChangeDetectionStrategy.OnPush
})
export class ToolbarComponent implements OnChanges,OnDestroy {

  @Input({required:true}) data!:datasGlobalI;

  @Output() buttonClick=new EventEmitter<ButtonEventI>();
  @Output() backClick=new EventEmitter<Event>();

  @Output() searchChange=new EventEmitter<{data:datasGlobalI;value:unknown}>();
  @Output() searchSubmit=new EventEmitter<{data:datasGlobalI;value:unknown}>();

  @Output() filterChange=new EventEmitter<{data:datasGlobalI;value:unknown;values:Record<string,unknown>}>();
  @Output() filtersChange=new EventEmitter<Record<string,unknown>>();

  @Output() sortChange=new EventEmitter<{data:datasGlobalI;direction:UISortDirectionEnum}>();
  @Output() viewChange=new EventEmitter<{data:datasGlobalI;value:unknown}>();

  searchValue='';
  filterValues:Record<string,unknown>={};

  selectedSort?:datasGlobalI;
  selectedView?:datasGlobalI;

  sortDirection=UISortDirectionEnum.Asc;

  readonly SortDirection=UISortDirectionEnum;

  private searchTimer?:ReturnType<typeof setTimeout>;

  ngOnChanges(changes:SimpleChanges):void {
    if(changes['data']) this.init();
  }

  ngOnDestroy():void {
    if(this.searchTimer) clearTimeout(this.searchTimer);
  }

  // ---------------------------------------------------------------------------
  // GENERAL
  // ---------------------------------------------------------------------------

  get title():string {
    return this.data.label??this.data.name??'';
  }

  get description():string {
    return this.data.description??'';
  }

  get icon():string|undefined {
    return this.data.configurations?.icon;
  }

  get disabled():boolean {
    return this.data.controls?.disabled===true;
  }

  get loading():boolean {
    return this.data.controls?.loading===true;
  }

  get showBack():boolean {
    return this.data.controls?.showBack===true;
  }

  get count():number|undefined {
    return this.data.configurations?.count;
  }

  get selectedCount():number {
    return this.data.configurations?.selectedCount??0;
  }

  // ---------------------------------------------------------------------------
  // INPUTS
  // ---------------------------------------------------------------------------

  get visibleInputs():datasGlobalI[] {
    return (this.data.inputs??[]).filter(input=>!this.isHidden(input));
  }

  get searchInput():datasGlobalI|undefined {
    return this.visibleInputs.find(input=>
      input.configurations?.action===UIActionEnum.Search
    );
  }

  get filters():datasGlobalI[] {
    return this.visibleInputs.filter(input=>
      input.configurations?.action===UIActionEnum.Filter
    );
  }

  get sorts():datasGlobalI[] {
    return this.visibleInputs.filter(input=>
      input.configurations?.action===UIActionEnum.Sort
    );
  }

  get views():datasGlobalI[] {
    return this.visibleInputs.filter(input=>
      input.configurations?.action===UIActionEnum.View
    );
  }

  // ---------------------------------------------------------------------------
  // BUTTONS
  // ---------------------------------------------------------------------------

  get activeButtons():datasGlobalI[] {
    return (this.data.buttons??[]).filter(button=>{
      if(this.isHidden(button)) return false;

      if(button.controls?.selectionOnly===true){
        return this.selectedCount>0;
      }

      return true;
    });
  }

  // ---------------------------------------------------------------------------
  // DISPLAY
  // ---------------------------------------------------------------------------

  get hasSecondaryRow():boolean {
    return this.filters.length>0||this.sorts.length>0;
  }

  get searchPlaceholder():string {
    return this.searchInput?.configurations?.placeholder??'Rechercher...';
  }

  get searchDelay():number {
    return this.searchInput?.configurations?.debounce??300;
  }

  getViewIcon(view:datasGlobalI):string {
    if(view.configurations?.icon) return view.configurations.icon;

    switch(view.configurations?.viewMode){
      case UIViewModeEnum.Grid:return 'pi pi-th-large';
      case UIViewModeEnum.List:return 'pi pi-list';
      default:return 'pi pi-table';
    }
  }

  isHidden(data:datasGlobalI):boolean {
    return data.controls?.hidden===true;
  }

  isDisabled(data:datasGlobalI):boolean {
    return this.disabled||data.controls?.disabled===true;
  }

  // ---------------------------------------------------------------------------
  // BACK
  // ---------------------------------------------------------------------------

  onBack(event:Event):void {
    if(this.disabled) return;
    this.backClick.emit(event);
  }

  // ---------------------------------------------------------------------------
  // SEARCH
  // ---------------------------------------------------------------------------

  onSearchInput(event:Event):void {
    const search=this.searchInput;

    if(!search||this.isDisabled(search)) return;

    this.searchValue=(event.target as HTMLInputElement).value;

    if(this.searchTimer) clearTimeout(this.searchTimer);

    this.searchTimer=setTimeout(()=>{
      this.searchChange.emit({
        data:search,
        value:this.searchValue
      });
    },this.searchDelay);
  }

  onSearchSubmit():void {
    const search=this.searchInput;

    if(!search||this.isDisabled(search)) return;

    if(this.searchTimer) clearTimeout(this.searchTimer);

    this.searchValue=this.searchValue.trim();

    const event={
      data:search,
      value:this.searchValue
    };

    this.searchChange.emit(event);
    this.searchSubmit.emit(event);
  }

  clearSearch():void {
    const search=this.searchInput;

    if(!search||this.isDisabled(search)) return;

    if(this.searchTimer) clearTimeout(this.searchTimer);

    this.searchValue='';

    const event={
      data:search,
      value:''
    };

    this.searchChange.emit(event);
    this.searchSubmit.emit(event);
  }

  // ---------------------------------------------------------------------------
  // FILTER
  // ---------------------------------------------------------------------------

  onFilterChange(filter:datasGlobalI,value:unknown):void {
    if(this.isDisabled(filter)) return;

    this.filterValues={
      ...this.filterValues,
      [filter.dataKey]:value
    };

    this.filterChange.emit({
      data:filter,
      value,
      values:{...this.filterValues}
    });

    this.filtersChange.emit({...this.filterValues});
  }

  clearFilters():void {
    if(this.disabled) return;

    this.filterValues=Object.fromEntries(
      this.filters.map(filter=>[
        filter.dataKey,
        undefined
      ])
    );

    this.filtersChange.emit({...this.filterValues});
  }

  // ---------------------------------------------------------------------------
  // SORT
  // ---------------------------------------------------------------------------

  onSortChange(sort:datasGlobalI|null|undefined):void {
    if(!sort||this.isDisabled(sort)) return;

    this.selectedSort=sort;

    this.sortDirection=
      sort.configurations?.sortDirection??
      this.sortDirection;

    this.sortChange.emit({
      data:sort,
      direction:this.sortDirection
    });
  }

  toggleSortDirection():void {
    if(!this.selectedSort||this.disabled) return;

    this.sortDirection=
      this.sortDirection===UISortDirectionEnum.Asc
        ?UISortDirectionEnum.Desc
        :UISortDirectionEnum.Asc;

    this.sortChange.emit({
      data:this.selectedSort,
      direction:this.sortDirection
    });
  }

  // ---------------------------------------------------------------------------
  // VIEW
  // ---------------------------------------------------------------------------

  setView(view:datasGlobalI):void {
    if(this.isDisabled(view)) return;
    if(this.selectedView?._id===view._id) return;

    this.selectedView=view;

    this.viewChange.emit({
      data:view,
      value:view.configurations?.viewMode??view.value??view.dataKey
    });
  }

  // ---------------------------------------------------------------------------
  // BUTTON
  // ---------------------------------------------------------------------------

  onButtonClick(event:ButtonEventI):void {
    if(this.disabled) return;
    this.buttonClick.emit(event);
  }

  // ---------------------------------------------------------------------------
  // INIT
  // ---------------------------------------------------------------------------

  private init():void {
    if(!this.data) return;

    const search=this.searchInput;

    this.searchValue=String(
      search?.value??
      search?.default??
      ''
    );

    this.filterValues=Object.fromEntries(
      this.filters.map(filter=>[
        filter.dataKey,
        filter.value??filter.default
      ])
    );

    this.selectedSort=
      this.sorts.find(sort=>sort.controls?.selected===true)??
      this.sorts[0];

    this.sortDirection=
      this.selectedSort?.configurations?.sortDirection??
      UISortDirectionEnum.Asc;

    this.selectedView=
      this.views.find(view=>view.controls?.selected===true)??
      this.views[0];
  }
}