import { Component } from '@angular/core';

@Component({
  selector: 'pus-modal',
  standalone: false,
  templateUrl: './modal.component.html',
  styleUrl: './modal.component.scss',
})
export class ModalComponent {

}
