import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { datasGlobalI } from '../../global/interface/data.interface';
import { UIViewModeEnum } from '../../global/interface/data.enums';
import { ButtonEventI } from '../button/button.component';

@Component({
  selector:'pus-data-view',
  standalone:false,
  templateUrl:'./data-view.component.html',
  styleUrl:'./data-view.component.scss',
  changeDetection:ChangeDetectionStrategy.OnPush
})
export class DataViewComponent implements OnChanges {

  @Input({required:true}) data!:datasGlobalI;

  @Output() rowClick=new EventEmitter<{data:datasGlobalI;resource:Record<string,unknown>;event:Event}>();
  @Output() rowDoubleClick=new EventEmitter<{data:datasGlobalI;resource:Record<string,unknown>;event:Event}>();
  @Output() selectionChange=new EventEmitter<Record<string,unknown>[]>();
  @Output() pageChange=new EventEmitter<{data:datasGlobalI;event:any}>();
  @Output() sortChange=new EventEmitter<{data:datasGlobalI;event:any}>();
  @Output() buttonClick=new EventEmitter<{button:datasGlobalI;resource:Record<string,unknown>;event?:Event}>();

  selection:Record<string,unknown>[]=[];

  ngOnChanges(changes:SimpleChanges):void {
    if(changes['data']) this.selection=[];
  }

  // ---------------------------------------------------------------------------
  // DATA
  // ---------------------------------------------------------------------------

  get resources():Record<string,unknown>[] {
    return this.data.resources??[];
  }

  get columns():datasGlobalI[] {
    return (this.data.columns??[]).filter(column=>!this.isHidden(column));
  }

  get buttons():datasGlobalI[] {
    return (this.data.buttons??[]).filter(button=>!this.isHidden(button));
  }

  // ---------------------------------------------------------------------------
  // STATE
  // ---------------------------------------------------------------------------

  get disabled():boolean {
    return this.data.controls?.disabled===true;
  }

  get loading():boolean {
    return this.data.controls?.loading===true;
  }

  get selectable():boolean {
    return this.data.controls?.selectable===true;
  }

  get multiple():boolean {
    return this.data.controls?.multiple===true;
  }

  get paginator():boolean {
    return this.data.controls?.paginator===true;
  }

  get lazy():boolean {
    return this.data.controls?.lazy===true;
  }

  get stripedRows():boolean {
    return this.data.controls?.stripedRows===true;
  }

  get showGridlines():boolean {
    return this.data.controls?.showGridlines===true;
  }

  get resizableColumns():boolean {
    return this.data.controls?.resizable===true;
  }

  get reorderableColumns():boolean {
    return this.data.controls?.reorderable===true;
  }

  // ---------------------------------------------------------------------------
  // VIEW
  // ---------------------------------------------------------------------------

  get viewMode():UIViewModeEnum {
    return this.data.configurations?.viewMode??UIViewModeEnum.Table;
  }

  get isTable():boolean {
    return this.viewMode===UIViewModeEnum.Table;
  }

  get isList():boolean {
    return this.viewMode===UIViewModeEnum.List;
  }

  get isGrid():boolean {
    return this.viewMode===UIViewModeEnum.Grid;
  }

  // ---------------------------------------------------------------------------
  // PAGINATION
  // ---------------------------------------------------------------------------

  get pageSize():number {
    return this.data.configurations?.pageSize??10;
  }

  get pageIndex():number {
    return this.data.configurations?.pageIndex??0;
  }

  get totalRecords():number {
    return this.data.configurations?.totalRecords??this.resources.length;
  }

  get rowsPerPageOptions():number[] {
    return this.data.configurations?.rowsPerPageOptions??[10,25,50,100];
  }

  get trackBy():string {
    return this.data.configurations?.trackBy??'_id';
  }

  // ---------------------------------------------------------------------------
  // COLUMN
  // ---------------------------------------------------------------------------

  isHidden(data:datasGlobalI):boolean {
    return data.controls?.hidden===true;
  }

  isSortable(column:datasGlobalI):boolean {
    return column.controls?.sortable===true;
  }

  getColumnLabel(column:datasGlobalI):string {
    return column.label??column.name;
  }

  getColumnIcon(column:datasGlobalI):string|undefined {
    return column.configurations?.icon;
  }

  getCellValue(resource:Record<string,unknown>,column:datasGlobalI):unknown {
    const value=this.resolvePath(resource,column.dataKey);

    if(value===null||value===undefined) return '';

    const prefix=column.configurations?.prefix??'';
    const suffix=column.configurations?.suffix??'';

    return `${prefix}${this.formatValue(value)}${suffix}`;
  }

  // ---------------------------------------------------------------------------
  // SELECTION
  // ---------------------------------------------------------------------------

  isSelected(resource:Record<string,unknown>):boolean {
    return this.selection.some(item=>this.getResourceKey(item)===this.getResourceKey(resource));
  }

  toggleSelection(resource:Record<string,unknown>):void {
    if(!this.selectable||this.disabled) return;

    const key=this.getResourceKey(resource);

    if(this.multiple){
      this.selection=this.isSelected(resource)
        ?this.selection.filter(item=>this.getResourceKey(item)!==key)
        :[...this.selection,resource];
    }else{
      this.selection=this.isSelected(resource)?[]:[resource];
    }

    this.selectionChange.emit([...this.selection]);
  }

  onTableSelectionChange(value:Record<string,unknown>|Record<string,unknown>[]|null):void {
    if(Array.isArray(value)) this.selection=value;
    else this.selection=value?[value]:[];

    this.selectionChange.emit([...this.selection]);
  }

  // ---------------------------------------------------------------------------
  // EVENTS
  // ---------------------------------------------------------------------------

  onRowClick(resource:Record<string,unknown>,event:Event):void {
    if(this.disabled) return;

    if(this.selectable) this.toggleSelection(resource);

    this.rowClick.emit({
      data:this.data,
      resource,
      event
    });
  }

  onRowDoubleClick(resource:Record<string,unknown>,event:Event):void {
    if(this.disabled) return;

    this.rowDoubleClick.emit({
      data:this.data,
      resource,
      event
    });
  }

  onPage(event:any):void {
    this.pageChange.emit({
      data:this.data,
      event
    });
  }

  onSort(event:any):void {
    this.sortChange.emit({
      data:this.data,
      event
    });
  }

  onButtonClick(event:ButtonEventI,resource:Record<string,unknown>):void {
    this.buttonClick.emit({
      button:event.button,
      resource,
      event:event.event
    });
  }

  trackResource(resource:Record<string,unknown>,index:number):unknown {
    return this.getResourceKey(resource)??index;
  }

  // ---------------------------------------------------------------------------
  // PRIVATE
  // ---------------------------------------------------------------------------

  private getResourceKey(resource:Record<string,unknown>):unknown {
    return this.resolvePath(resource,this.trackBy);
  }

  private resolvePath(object:Record<string,unknown>,path:string):unknown {
    if(!path) return undefined;

    return path.split('.').reduce<unknown>((value,key)=>{
      if(value===null||value===undefined||typeof value!=='object') return undefined;
      return (value as Record<string,unknown>)[key];
    },object);
  }

  private formatValue(value:unknown):string {
    if(value instanceof Date) return value.toLocaleString();

    if(Array.isArray(value)){
      return value.map(item=>this.formatValue(item)).join(', ');
    }

    if(typeof value==='object'){
      try{return JSON.stringify(value);}
      catch{return String(value);}
    }

    return String(value);
  }
}