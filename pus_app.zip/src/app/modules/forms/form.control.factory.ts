import { AbstractControl, FormControl, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { dataTypeE } from '../../global/interface/data.enums';
import { dataRequiredType, datasGlobalI } from '../../global/interface/data.interface';
import { InputTypeEnum } from '../../global/interface/input-form.enum';

const ruleValue=<T>(rule?:T|[T,string]):T|undefined=>Array.isArray(rule)?rule[0]:rule;

const requiredValue=(required?:dataRequiredType):boolean=>Array.isArray(required)?required[0]:required===true;

const dateLimit=(limit:unknown):number|null=>{
  const raw=Array.isArray(limit)?limit[0]:limit;
  const timestamp=raw instanceof Date?raw.getTime():new Date(String(raw)).getTime();
  return Number.isNaN(timestamp)?null:timestamp;
};

const dateValidator=(limit:unknown,mode:'min'|'max'):ValidatorFn=>{
  const boundary=dateLimit(limit);

  return (control:AbstractControl):ValidationErrors|null=>{
    if(boundary===null||control.value===null||control.value==='') return null;

    const value=new Date(control.value).getTime();

    if(Number.isNaN(value)) return {date:true};
    if(mode==='min'&&value<boundary) return {minDate:true};
    if(mode==='max'&&value>boundary) return {maxDate:true};

    return null;
  };
};

export function inputValidators(dataKey:datasGlobalI):ValidatorFn[]{
  const validators:ValidatorFn[]=[];
  const controls=dataKey.controls;
  const limits=dataKey.limits;

  if(requiredValue(controls?.required)) validators.push(Validators.required);
  if(limits?.pattern) validators.push(Validators.pattern(limits.pattern));

  if(dataKey.dataType===dataTypeE.Date){
    if(limits?.min!==undefined) validators.push(dateValidator(limits.min,'min'));
    if(limits?.max!==undefined) validators.push(dateValidator(limits.max,'max'));
  }else{
    const min=ruleValue(limits?.min as number|[number,string]|undefined);
    const max=ruleValue(limits?.max as number|[number,string]|undefined);

    if(typeof min==='number') validators.push(Validators.min(min));
    if(typeof max==='number') validators.push(Validators.max(max));
  }

  const minLength=ruleValue(limits?.minLength);
  const maxLength=ruleValue(limits?.maxLength);
  const minItems=ruleValue(limits?.minItems);
  const maxItems=ruleValue(limits?.maxItems);

  if(typeof minLength==='number') validators.push(Validators.minLength(minLength));
  if(typeof maxLength==='number') validators.push(Validators.maxLength(maxLength));
  if(typeof minItems==='number') validators.push(Validators.minLength(minItems));
  if(typeof maxItems==='number') validators.push(Validators.maxLength(maxItems));

  return validators;
}

export function inputDefaultValue(dataKey:datasGlobalI):unknown{
  if(dataKey.default!==undefined){
    return dataKey.dataType===dataTypeE.Date&&typeof dataKey.default==='string'
      ?new Date(dataKey.default)
      :dataKey.default;
  }

  switch(dataKey.inputType){
    case InputTypeEnum.MultiSelect:
    case InputTypeEnum.Checkbox:
      return [];

    case InputTypeEnum.RangeSlider:
      return [
        Number(ruleValue(dataKey.limits?.min as number|[number,string]|undefined)??0),
        Number(ruleValue(dataKey.limits?.max as number|[number,string]|undefined)??100)
      ];

    case InputTypeEnum.ToggleSwitch:
      return false;

    default:
      return null;
  }
}

export function createInputControl(dataKey:datasGlobalI,value?:unknown):FormControl{
  return new FormControl(
    {
      value:value!==undefined?value:inputDefaultValue(dataKey),
      disabled:dataKey.controls?.disabled===true
    },
    inputValidators(dataKey)
  );
}